let money,
    income,
    addExpences,
    deposit,
    mission,
    period;

alert('Hello, world!');
console.log('Hidden message');